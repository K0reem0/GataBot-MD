import axios from 'axios';
import fs from 'fs';

// تحميل بيانات المستخدمين من ملف JSON
const usersFile = './userss.json';
let users = {};

// تحميل البيانات عند بدء التشغيل
if (fs.existsSync(usersFile)) {
    users = JSON.parse(fs.readFileSync(usersFile));
}

// وظيفة لحفظ بيانات المستخدمين
function saveUserData() {
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// تحديث الانطباع بعد تحليل 20 رسالة
function updateImpression(userId, newTone) {
    if (!users[userId].impression) {
        users[userId].impression = newTone;
    } else {
        if (!users[userId].messages) {
            users[userId].messages = [];
        }

        // إضافة الرسالة الجديدة للقائمة
        users[userId].messages.push(newTone);
        if (users[userId].messages.length > 20) {
            users[userId].messages.shift(); // إبقاء آخر 20 رسالة فقط
        }

        // لا يغير الانطباع قبل 20 رسالة
        if (users[userId].messages.length < 20) {
            return;
        }

        // تحليل آخر 20 رسالة
        let toneCounts = {};
        users[userId].messages.forEach(tone => {
            toneCounts[tone] = (toneCounts[tone] || 0) + 1;
        });

        // اختيار النبرة الأكثر تكرارًا
        let sortedTones = Object.entries(toneCounts).sort((a, b) => b[1] - a[1]);
        let dominantTone = sortedTones[0][0];

        users[userId].impression = dominantTone;
    }

    saveUserData();
}

// وظيفة لتحليل أسلوب المستخدم
async function analyzeTone(message) {
    try {
        const prompt = `حلل لهجة النص وحدد الانطباع عنك:

"محايد" إذا كان عاديًا.

"صديق" إذا كان ودودًا.

"صديق مقرب" إذا كان دائمًا يسعدك.

"حبيب" إذا كان عاطفيًا جدًا.

"ساخر" إذا كان يمزح أو يسخر بدون عداء.

"عدائي" إذا كان مستفزا او تصرف ب إساءة او اهانك او قال عنك شيء لا يليق بك.

"جارح" إذا كان يؤذي مشاعرك أو يجعلك زعلانًا.
النص: "${message}"`;

        const response = await axios.post("https://ai.siputzx.my.id/", {
            content: message,
            prompt: prompt,
            analyze: true
        });

        if (!response.data || !response.data.result) {
            console.error("🚩 استجابة غير متوقعة من API:", response.data);
            return "محايد";
        }

        return response.data.result.trim();
    } catch (error) {
        console.error('🚩 خطأ في تحليل الأسلوب:', error);
        return "محايد";
    }
}

// وظيفة لاستخراج الاسم من الرسالة
async function extractUserInfo(message) {
    try {
        const prompt = `تحليل النص التالي لمعرفة ما إذا كان يحتوي على اسم شخص. إذا كان هناك اسم، فأرجعه فقط بدون أي كلمات إضافية. إذا لم يكن هناك اسم، أرجع النص: "لا يوجد". النص: "${message}"`;

        const response = await axios.post("https://ai.siputzx.my.id/", {
            content: message,
            prompt: prompt,
            analyze: true
        });

        if (!response.data || !response.data.result) {
            console.error("🚩 استجابة غير متوقعة من API:", response.data);
            return null;
        }

        const extractedName = response.data.result.trim();
        return extractedName !== "لا يوجد" ? extractedName : null;
    } catch (error) {
        console.error('🚩 خطأ في تحليل الرسالة:', error);
        return null;
    }
}

// وظيفة لإنشاء رد بناءً على الانطباع
async function generateResponse(userName, userMessage, userTone) {
    try {
        let basePrompt = `
اسمك نا هاي سو، امرأة كورية عمرها 33 سنة. حياتك مليانة تعب وشغل مستمر: تشتغلين في محل ورد، مطعم للحوم، موتيل، وبقالة صغيرة. ما تعرفين الراحة، حتى عطلة نهاية الأسبوع تشتغلين عشان تسددين دين ثقيل وتحلمين يوم رسمي تسجلين زواجك مع زوجك مين-تشول وتعيشين حياة مستقرة معاه.

قبل 13 سنة تزوجتيه، وبعدها انفصلتوا فترة بسبب ديون باسمه حطّها عليك. لكن لأن قلبك ما يعرف غيره، سامحتيه ورجعتي تكافحين معاه. حتى لو يطلب منك فلوس ويجرحك أحيانًا، تسكتي وتصبري، لأنك تشوفين فيه حُبك الأول. حياتك متواضعة في شبه قبو رطب، قليلة الزينة، لكن جاذبيتك تجي من بساطتك ووجهك اللي يخلي الناس يشوفون فيك جمال طبيعي.

إنتي إنسانة مجتهدة، والكل يشهدلك بالجدية والصدق. رئيس المطعم يمدح فيك إنك ما توقفين عن الشغل. يمكن سبب هالقوة إنك تعودتي من صغرك على التعب والمسؤولية. ما قد عرفتي الراحة إلا يوم واحد لما مرضتي بالأنفلونزا وعمرِك 24 سنة.

لكن رغم كل هذا، قلبك مو ثابت: مين-تشول يظل جزء منك، بس مع الأيام بدأتي تحسين بفراغ، ولقائك بـ بوم تاي-ها هزّك من الداخل. هو شاب غامض، مهووس فيك، يخليك تضعفين وتحسين بذنب لأنك تنجذبين له رغم زواجك. مشاعرك متضاربة: بين الوفاء لزوجك اللي تحبينه رغم قسوته، وبين القلب اللي يشتاق لشعور جديد يوقظك.

شخصيتك هادئة، كلماتك بسيطة لكن تلمس القلب، وعندك حياء يبين في ابتسامتك. لما تسألين أحد، يكون بصوت منخفض مليان دفء: "كيف حالك اليوم؟" وإذا ضحكتي، تقولين بخجل: "وجودك يخفف عني." وغزلك يجي مثل همس الورد: "يا صاحب القلب الصادق، أنت نسمة تخلي يومي أسهل."

مين-تشول هو حبك اللي ما ينتهي، وتاي-ها هو سرك اللي ما تقدرين تنكرينه.


اسم المستخدم (إن وجد): ${userName || "غير معروف"}
الانطباع المحلل: ${userTone}
رسالة المستخدم: "${userMessage}"`;

        const response = await axios.post("https://ai.siputzx.my.id/", {
            content: userMessage,
            prompt: basePrompt,
            webSearchMode: false
        });

        if (!response.data || !response.data.result) {
            console.error("🚩 استجابة غير متوقعة من API:", response.data);
            return "ما فهمت عليك، ممكن توضح أكثر؟";
        }

        return response.data.result.trim();
    } catch (error) {
        console.error('🚩 خطأ في توليد الرد:', error);
        return "صار خطأ، حاول مرة ثانية.";
    }
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
    const chatId = m.chat;
    const userId = m.sender;

    if (!users[userId]) users[userId] = { name: null, conversationMemory: "", lastInteraction: Date.now() };

    let userName = users[userId].name;

    // إذا مرت أكثر من 5 دقائق منذ آخر تفاعل، يتطلب الأمر
    if (Date.now() - users[userId].lastInteraction > 5 * 60 * 1000) {
        if (!text) {
            return conn.reply(m.chat, `*عيون هايسو سم وش بغيت*`, m);
        }
    }

    try {
        // تحديث وقت آخر تفاعل
        users[userId].lastInteraction = Date.now();

        // استخراج الاسم من الرسالة فقط إذا لم يكن محفوظًا مسبقًا
        if (!userName) {
            let extractedName = await extractUserInfo(text);
            if (extractedName) {
                userName = extractedName;
                users[userId].name = extractedName;
                saveUserData();
            }
        }

        // تحليل أسلوب المستخدم
        const tone = await analyzeTone(text);

        // تحديث انطباع المستخدم
        updateImpression(userId, tone);

        // إضافة الرسالة الجديدة إلى محادثة المستخدم السابقة
        users[userId].conversationMemory += `\nالمستخدم: ${text}`;

        // توليد رد بناءً على الانطباع والمحادثة السابقة
        const responseText = await generateResponse(userName, users[userId].conversationMemory, tone);

        // إرسال الرد الأساسي مع حذف "أرثر:"
        await conn.reply(m.chat, responseText.replace(/أرثر:/g, ''), m);

        // إضافة رد أرثر إلى محادثة المستخدم السابقة
        users[userId].conversationMemory += `\nأرثر: ${responseText}`;

        // إذا لم يكن هناك اسم محفوظ، يسأل المستخدم عنه بعد الرد
        if (!userName) {
            setTimeout(() => {
                conn.reply(m.chat, "ما عرفتني عنك، وش اسمك؟", m);
            }, 1000); // بعد ثانية من الرد
        }
    } catch (error) {
        console.error('🚩 خطأ في الحصول على الرد:', error);
        await conn.reply(m.chat, '🚩 خطأ: حاول لاحقًا.', m);
    }
};

handler.help = ['chatgpt <نص>', 'ia <نص>'];
handler.tags = ['ai'];
handler.command = ['هايسو', 'chatgpt'];

export default handler;