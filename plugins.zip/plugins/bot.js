let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender];
    let name = await conn.getName(m.sender);
    let taguser = '@' + m.sender.split("@")[0];

    // مجموعة الصور
    let images = [
        'https://qu.ax/pkVKa.jpg',
        'https://qu.ax/BUvDR.jpg',
        'https://qu.ax/uJopD.jpg',
        'https://qu.ax/jzNlc.jpg',
        'https://qu.ax/rhJHx.jpg',
        'https://qu.ax/Eadfb.jpg',
        'https://qu.ax/ictsc.jpg',
        'https://qu.ax/hyBnU.jpg',
        'https://qu.ax/tSzfo.jpg',
        'https://qu.ax/ZGjaG.jpg',
        'https://qu.ax/upaOQ.jpg',
        'https://qu.ax/YErqz.jpg',
        'https://qu.ax/uTlWt.jpg',
        'https://qu.ax/DtUSs.jpg',
        'https://qu.ax/HYSEc.jpg',
        'https://qu.ax/yoPbL.jpg',
        'https://qu.ax/pzFtu.jpg',
        'https://qu.ax/upaOQ.jpg'
        // تقدر تضيف روابط أكثر هنا
    ];

    // مجموعة الردود (أسلوب غزلي لطيف من "أليا تشان")
    let messages = [
    `أنا هنا لأجلك، لا تتردد تطلب أي شي 🩷 - أليا تشان`,
    `عيونك حلوة، بس أوامرك أحلى 🌸`,
    `وش تبيني أسوي؟ أنا بالخدمة يا روحي 💕`,
    `همسة ناعمة: لا أحد يطلبني إلا أنت 🌷`,
    `أوامرك يعيوني 💖 - هايسو في خدمتك`,
    `هل ترغب بمساعدة أو بقلبي؟ 🤍`,

    // ردود غزلية إضافية
    `عيون هايسو تدرين انتِ مو بس بقلبي، إنت القلب نفسه 💓`,
    `يهلا بسبب ضحكتي وسبب سعادتي 🌹`,
    `كل شي فيني يشتاق لك حتى وأنا معك ✨`,
    `لو أقدر أعطيك عيوني عشان تشوف نفسك فيني.. ما كنت ترددت لحظة 👀❤️`,
    `قربي منك يخليني أنسى العالم كله 🌎💕`,
    `صوتك يكفي يخليني أطير من الفرح 🎶💖`,
    `معك أحس إن الدنيا بخير 🌸`,
    `إنت أحلى صدفة صارت بحياتي 🌷`,
    `وجودك بجنبي هو أكبر هدية من ربي 🎁💞`,
    `أحبك أكثر من كل الكلام اللي أقدر أقوله لك 💕`
];

    // اختيار عشوائي
    let image = images[Math.floor(Math.random() * images.length)];
    let message = messages[Math.floor(Math.random() * messages.length)];

    conn.sendFile(m.chat, image, 'image.jpg', message, m);
};

// كلمات التفعيل
handler.customPrefix = /^(bot|بوت|بووت|هايسو)$/i;
handler.command = new RegExp;

export default handler;
